// Quitar el siguiente alert en produccion
// alert("Estoy aprendiendo JavaScript");


nombre = "Profesor";
var alumno = "Carlos";
var profesor = "Ruben";

function saludar(){
  alert("Buenos días");
}

var miObjeto = {
  nombre: "Objeto",
  edad: 10
};

var despedirse = function(){
  alert('Hasta mañana');
};

var noDefinida = "Esta variable ya ha sido definida";
//alert(noDefinida);

var cita = "\"Solo sé que nada sé\" por Socrates";
alert(cita);