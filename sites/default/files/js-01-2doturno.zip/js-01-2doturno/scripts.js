// Quitar este alert en produccion
// alert('Estoy programando');

(function(){
  function saludar(){
    var saludo = "Buenos Dias";
    alert(saludo);
  }

  // saludar();

  var miObjeto = {
    nombre: "telefono"
  };

  var despedirse = function(){
    console.log("Adios");
  };

  var nombre = "Alvaro";

  var noDefinida;

  noDefinida = "Ahora ya tengo un valor";

  var a = 1;
  // alert(++a);
  // alert(a);
}());

// alert(nombre);

// sublimelinter jshint